public class A
{
    void foo(int t1, double t2)
	{  
		//void, so I'll just do nothing
	}
    int bar(int t1, double t2, long t3)
	{ 
		return 1;
	}
    static double doo()
	{
		return 0.0;
	}
}