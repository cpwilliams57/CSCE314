
/**
 * Write a description of class Point here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Point
{
    int x;
    int y;
    public Point(int xcord, int ycord){
        x = xcord;
        y = ycord; 
    }
    public int getX(){
        return x;
    }
    public int getY(){
        return y;
    }
}
